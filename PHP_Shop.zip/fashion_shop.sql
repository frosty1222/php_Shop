-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 23, 2022 lúc 04:43 AM
-- Phiên bản máy phục vụ: 10.4.19-MariaDB
-- Phiên bản PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `fashion_shop`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `color`, `size`, `quantity`, `created_at`, `updated_at`) VALUES
(8, '30', '#50bf31', 'XL', '2', '2021-11-14 18:22:38', '2021-11-14 18:22:38'),
(9, '32', '#f0660a', 'M', '2', '2021-11-14 18:43:51', '2021-11-14 18:43:51'),
(10, '32', '#f0660a', 'M', '2', '2021-11-14 18:46:38', '2021-11-14 18:46:38'),
(11, '32', '#f0660a', 'M', '2', '2021-11-14 18:47:29', '2021-11-14 18:47:29'),
(12, '32', '#f0660a', 'M', '2', '2021-11-14 18:48:54', '2021-11-14 18:48:54'),
(13, '32', '#f0660a', 'S', '2', '2021-11-14 18:49:34', '2021-11-14 18:49:34'),
(14, '32', '#f0660a', 'S', '2', '2021-11-14 18:50:26', '2021-11-14 18:50:26'),
(15, '30', '#50bf31', 'XL', '2', '2021-11-14 18:57:18', '2021-11-14 18:57:18'),
(16, '33', '#d81818', 'XS', '2', '2021-11-14 18:59:02', '2021-11-14 18:59:02'),
(17, '35', '#083ddd', 'S', '2', '2021-11-16 01:06:35', '2021-11-16 01:06:35'),
(18, '30', '', 'XL', '', '2021-11-16 09:02:49', '2021-11-16 09:02:49'),
(19, '30', '', 'XL', '2', '2022-01-22 20:51:00', '2022-01-22 20:51:00'),
(20, '30', '', 'XL', '2', '2022-01-22 20:51:45', '2022-01-22 20:51:45'),
(21, '32', '', 'M', '2', '2022-01-23 00:24:13', '2022-01-23 00:24:13');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`id`, `name`, `image`, `status`) VALUES
(1, 'men', 'https://rlv.zcache.com/broken_image_jpg_gif_png_jpeg_t_shirt-r20259504c487436bb7fe6ebc9d73db31_k2gm8_307.jpg', 1),
(2, 'girl', 'https://static.dosi-in.com/images/detailed/114/dosiin-tinderella-met-114247114247.jpg', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `color`
--

CREATE TABLE `color` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `color` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `color`
--

INSERT INTO `color` (`id`, `product_id`, `color`, `size`, `created_at`, `updated_at`) VALUES
(1, 30, '#50bf31', 'XL', '2021-09-08 17:33:15', '2021-09-08 17:33:15'),
(2, 33, '#24a887', 'XXL', '2021-11-14 15:30:25', '2021-11-14 15:30:25'),
(3, 33, '#d81818', 'L', '2021-11-14 15:30:33', '2021-11-14 15:30:33'),
(4, 33, '#1b1818', 'XS', '2021-11-14 15:30:43', '2021-11-14 15:30:43'),
(5, 28, '#51d11a', 'L', '2021-11-14 15:31:35', '2021-11-14 15:31:35'),
(6, 28, '#272525', 'M', '2021-11-14 15:31:45', '2021-11-14 15:31:45'),
(7, 28, '#d5e133', 'L', '2021-11-14 15:31:56', '2021-11-14 15:31:56'),
(8, 32, '#de1b1b', 'S', '2021-11-14 15:33:01', '2021-11-14 15:33:01'),
(9, 32, '#f0660a', 'M', '2021-11-14 15:33:10', '2021-11-14 15:33:10'),
(10, 206, '#817474', 'XS', '2021-11-14 15:33:32', '2021-11-14 15:33:32'),
(11, 206, '#b41d1d', 'L', '2021-11-14 15:33:40', '2021-11-14 15:33:40'),
(12, 35, '#083ddd', 'S', '2021-11-14 15:35:50', '2021-11-14 15:35:50'),
(13, 34, '#1459c8', 'XS', '2021-11-14 15:36:10', '2021-11-14 15:36:10'),
(14, 36, '#000000', 'L', '2021-11-14 15:36:21', '2021-11-14 15:36:21');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `contact`
--

INSERT INTO `contact` (`id`, `name`, `phone`, `email`, `note`) VALUES
(1, '', 'Lò Văn Đồng', '0353802878', 'lodong601@gmail.com'),
(2, '', 'Lò Văn Đồng', '0353802878', 'lodong601@gmail.com'),
(3, 'Lò Văn Đồng', '0353802878', 'lodong601@gmail.com', 'i want to get my orders as soon as possible '),
(4, 'Lò Văn Đồng', '0353802878', 'lodong601@gmail.com', 'hello');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_price` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `home_number` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pay_type` int(11) NOT NULL,
  `total_price` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `payment`
--

INSERT INTO `payment` (`id`, `cart_id`, `name`, `email`, `address`, `phone`, `home_number`, `note`, `color`, `size`, `pay_type`, `total_price`, `created_at`, `updated_at`) VALUES
(287, 0, 'lò văn nam ', 'name@gmail.com', 'bản nà xa,thuận châu,sơn la ', '0234434533', '22', 'hello, can I get my items faster, please?', '', '', 1, 6000, '2021-08-25 17:18:30', '2021-08-25 17:18:30'),
(288, 0, 'lo van dong', 'lodong@gmail.com', 'ktx mỹ đình', '0353802879', '22', 'fdgdfgdfhgfd', '', '', 1, 6000, '2021-11-10 04:38:24', '2021-11-10 04:38:24'),
(289, 0, 'lo van dong', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802879', '22', '', '', '', 0, 3000, '2021-11-11 03:22:58', '2021-11-11 03:22:58'),
(290, 0, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802879', '22', 'zxvzxv', '', '', 1, 3000, '2021-11-14 10:16:29', '2021-11-14 10:16:29'),
(291, 0, 'lo van dong', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802879', '22', 'good', NULL, NULL, 0, 3000, '2021-11-16 02:10:20', '2021-11-16 02:10:20'),
(292, 0, 'lo van dong', 'lodong@gmail.com', 'thuận châu, sơn la', '0353802878', '21', 'i want to get item quickly', '#50bf31', 'XL', 1, 3000, '2021-11-16 02:27:25', '2021-11-16 02:27:25'),
(293, 0, 'Lò Văn Đồng', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802878', '22', 'nhanh', '#f0660a', 'M', 1, 6000, '2022-01-13 03:05:35', '2022-01-13 03:05:35'),
(294, 0, 'Lò Văn Đồng', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802878', '22', 'i want to get my item sooner before 20th', '', '', 1, 0, '2022-01-22 14:39:17', '2022-01-22 14:39:17'),
(295, 0, 'Lò Văn Đồng', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802878', '22', 'i wanna get my items before 22th', '', '', 1, 0, '2022-01-22 14:41:15', '2022-01-22 14:41:15'),
(296, 0, 'Lò Văn Đồng', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802878', '22', 'hello', '#50bf31', 'XL', 1, 6000, '2022-01-22 14:42:52', '2022-01-22 14:42:52');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `id` int(30) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(34) NOT NULL,
  `image` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `sale_price` int(23) NOT NULL,
  `category_id` tinyint(4) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp(6) NULL DEFAULT NULL ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `image`, `sale_price`, `category_id`, `created_at`, `updated_at`) VALUES
(28, 'sweater2', 2000, 'uploads/1_35fcbc35-8f2a-4545-85fc-fb8ad97e1010_1600x.jpg', 1500, 1, '2021-08-17', '2021-08-28 15:14:26.692889'),
(30, 'yellow', 2000, 'uploads/m-dv24solidmustard-diversify-original-imafkbzvhcn3vgs7.jpeg', 1500, 1, '2021-08-17', NULL),
(32, 'grey', 2000, 'uploads/grey.jpg', 1500, 1, '2021-08-17', NULL),
(33, 'Blue dot', 2000, 'uploads/1_72fd232f-fe4a-4746-96f6-7fa0b43efd14_2000x (1).jpg', 1500, 1, '2021-08-17', NULL),
(34, 'Blue back', 2500, 'uploads/5_7b5421d7-6709-4616-949e-71bdd8ef2013_2000x (1).jpg', 1500, 1, '2021-08-17', NULL),
(35, 'red T-shirt', 2000, 'uploads/DSC_7376_2000x.jpg', 1500, 1, '2021-08-17', NULL),
(36, 'sweater', 2500, 'uploads/1_17.jpg', 1500, 1, '2021-08-17', '2021-09-03 07:39:39.159864'),
(206, 'appa', 5000, 'uploads/1.jpg', 2500, 1, '2021-08-28', '2021-08-28 13:36:34.794828');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pro_image`
--

CREATE TABLE `pro_image` (
  `id` int(11) NOT NULL,
  `images` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rating_star`
--

CREATE TABLE `rating_star` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `star` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rating_star`
--

INSERT INTO `rating_star` (`id`, `name`, `email`, `content`, `star`, `product_id`, `created_at`, `updated_at`) VALUES
(19, 'lò văn Đồng', 'lodond@gmail.com', 'great', 4, 32, '2021-11-13 16:31:18', '2021-11-13 16:31:18'),
(20, 'lò văn Đồng', 'lodong601@gmail.com', 'great', 3, 33, '2021-11-14 08:26:34', '2021-11-14 08:26:34'),
(21, 'lò văn Đồng', 'lodong601@gmail.com', 'great', 3, 33, '2021-11-14 08:26:41', '2021-11-14 08:26:41'),
(22, 'lo dong', 'lodong12@gmail.com', 'great', 5, 28, '2021-11-15 04:01:07', '2021-11-15 04:01:07'),
(25, 'lo dong', 'lodong12@gmail.com', 'great', 5, 28, '2021-11-15 04:03:07', '2021-11-15 04:03:07'),
(26, 'lo dong', 'lodong12@gmail.com', 'great', 5, 28, '2021-11-15 04:05:23', '2021-11-15 04:05:23'),
(27, 'lo dong', 'lodong12@gmail.com', 'great', 2, 28, '2021-11-15 04:09:15', '2021-11-15 04:09:15'),
(28, 'lo dong', 'lodong12@gmail.com', 'great', 5, 28, '2021-11-15 04:09:40', '2021-11-15 04:09:40'),
(29, 'lo dong', 'lodong12@gmail.com', 'great', 5, 28, '2021-11-15 04:10:06', '2021-11-15 04:10:06'),
(30, 'lo dong', 'lodong12@gmail.com', 'great', 5, 28, '2021-11-15 04:10:18', '2021-11-15 04:10:18'),
(31, 'lò văn Đồng', 'lodond@gmail.com', 'good', 2, 32, '2021-11-15 04:10:50', '2021-11-15 04:10:50'),
(32, 'lò văn Đồng', 'lodond@gmail.com', 'good', 2, 32, '2021-11-15 04:10:50', '2021-11-15 04:10:50'),
(33, 'lò văn Đồng', 'lodond@gmail.com', 'good', 2, 32, '2021-11-15 04:10:59', '2021-11-15 04:10:59'),
(34, 'lò văn Đồng', 'lodond@gmail.com', 'good', 2, 32, '2021-11-15 04:13:26', '2021-11-15 04:13:26'),
(35, 'lò văn Đồng', 'lodond@gmail.com', 'good', 2, 32, '2021-11-15 04:14:05', '2021-11-15 04:14:05'),
(36, 'lò văn Đồng', 'lodond@gmail.com', 'good', 2, 32, '2021-11-15 04:14:59', '2021-11-15 04:14:59'),
(37, 'lo dong', 'lodond@gmail.com', 'good', 4, 30, '2021-11-15 04:36:14', '2021-11-15 04:36:14'),
(38, 'lo dong', 'lodond@gmail.com', 'good', 4, 30, '2021-11-15 04:36:18', '2021-11-15 04:36:18'),
(39, 'lo dong', 'lodond@gmail.com', 'good', 4, 30, '2021-11-15 04:36:27', '2021-11-15 04:36:27'),
(40, 'lo dong', 'lodond@gmail.com', 'good', 4, 30, '2021-11-15 04:39:08', '2021-11-15 04:39:08'),
(41, 'lo dong', 'lodond@gmail.com', 'good', 4, 30, '2021-11-15 04:39:17', '2021-11-15 04:39:17'),
(42, 'lo dong', 'lodond@gmail.com', 'good', 4, 30, '2021-11-15 04:42:57', '2021-11-15 04:42:57'),
(43, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:51:48', '2021-11-15 17:51:48'),
(44, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:51:53', '2021-11-15 17:51:53'),
(45, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:52:25', '2021-11-15 17:52:25'),
(46, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:52:53', '2021-11-15 17:52:53'),
(47, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:53:04', '2021-11-15 17:53:04'),
(48, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:53:28', '2021-11-15 17:53:28'),
(49, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:53:40', '2021-11-15 17:53:40'),
(50, 'Nguyễn văn Tưởng', 'lodong601@gmail.com', 'great', 5, 206, '2021-11-15 17:54:59', '2021-11-15 17:54:59'),
(51, 'dong lo', 'lodong343@gmail.com', 'this is perfect to me ', 5, 36, '2021-11-16 04:08:42', '2021-11-16 04:08:42'),
(52, 'dong lo', 'lodong343@gmail.com', 'this is perfect to me ', 5, 36, '2021-11-16 04:08:46', '2021-11-16 04:08:46'),
(53, 'dong lo', 'lodong343@gmail.com', 'this is perfect to me ', 5, 36, '2021-11-16 04:10:29', '2021-11-16 04:10:29'),
(54, 'dong lo', 'lodong343@gmail.com', 'this is perfect to me ', 5, 36, '2021-11-16 04:10:36', '2021-11-16 04:10:36'),
(55, 'dong lo', 'lodong343@gmail.com', 'this is perfect to me ', 5, 36, '2021-11-16 04:10:56', '2021-11-16 04:10:56');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(23) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `re_pass` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `address`, `phone`, `pass`, `re_pass`) VALUES
(4, 'lo van dong', 'lodong601@gmail.com', 'ktx mỹ đình', '0353802879', '827ccb0eea8a706c4c34', '12345'),
(5, 'van dong', 'lodong@gmail.com', 'hanoi', '0353802878', 'e10adc3949ba59abbe56', '123456');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `pro_image`
--
ALTER TABLE `pro_image`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `rating_star`
--
ALTER TABLE `rating_star`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `color`
--
ALTER TABLE `color`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT cho bảng `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT cho bảng `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=297;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT cho bảng `pro_image`
--
ALTER TABLE `pro_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT cho bảng `rating_star`
--
ALTER TABLE `rating_star`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
