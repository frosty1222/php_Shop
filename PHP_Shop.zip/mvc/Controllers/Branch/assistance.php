<?php
if (isset($_GET['run'])) {
    $action = $_GET['run'];
} else {
    $action = '';
}
$thanhcong = array();

switch($action){
    case 'pro': {
            $sum = $db->CountMember2();
            $pages = $sum / 4;
            $data = $db->pro_select();
            require_once('mvc/Views/CRUD/pro_list.php');
            break;
    }
    case'delete':{
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $tblTable = "pro_image";
                if ($db1->DeleteData($id, $tblTable)) {
                    header('location:index.php?controller=Branch&run=pro');
                }
            } else {
                echo 'delete is not successful';
            }
            break;
        }

    case'up_color':{
        if(isset($_GET['id'])){
            $id = $_GET['id'];
            $product= $db1->getproduct_id($id);
            if(isset($_POST['submit'])){
                    $product_id = $_GET['id'];
                    // $product_id = $_POST['product_id'];
                    $color = $_POST['color'];
                    $size = $_POST['size'];
                $db1->addproduct($id, $product_id,$color,$size);
            }
        }
        // echo '<pre/>';
        // print_r($_POST);
        // die();
        require_once('mvc/Views/shopping/color_size.php');
        break;
    }
    case 'admin':{
            $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
            $sum = $db->Countprocess();
            $pages = $sum / 3;
            $dat= $db1->getorderdetail1();
            require_once('mvc/Views/admin/index.php');
            break;
    }
    case'delete_ad':{
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $data1 = $db1->Delete($id);
                if($data1){
                    header('location:index.php?controller=Branch&run=admin');
                }
            }
               // echo '<pre/>';
                // print_r($data1);
                // die();
         require_once('mvc/Views/admin/index.php');
         break;
    }
    case'update_status':{
        if(isset($_GET['id'])){
            $id= $_GET['id'];
            $status = $_GET['status'];
            $data3 = $db1->update_status($id,$status);
            // echo '<pre/>';
            //     print_r($data3);
            //     die();
            if($data3){
                header('location:index.php?controller=Branch&run=admin');
                 
            }
        }
       break;
    }
    case 'status_up': {
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $status = $_GET['status'];
                $data4= $db1->update_status($id, $status);
                // echo '<pre/>';
                //     print_r($data4);
                //     die();
                if ($data4) {
                    header('location:index.php?controller=Branch&run=user_view');
                }
            }
            break;
        }
    case'user_view':{
            $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
            $sum = $db->Countprocess();
            $pages = $sum / 3;
            $data = $db1->getorderdetail();
            require_once('mvc/Views/admin/user_view.php');
            break;
    }
    // default: {
    //         require_once('mvc/Views/main.php');
    //     }
    case'contact':{
        if(isset($_POST['contact'])){
            $name = $_POST['name'];
            $phone = $_POST['phone'];
            $email = $_POST['email'];
            $note = $_POST['note'];
            $data = $db1->Contact($id, $name, $phone, $email, $note);
            if($data){
                header('location:index.php?controller=Branch&run=contact');
            }
        }
            require_once('mvc/Views/contact/contact.php');
            break;
    }
}
?>