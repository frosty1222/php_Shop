<?php 
   $db2 = new Mysqli('localhost','root','','fashion_shop');
   $db2->set_charset('utf8');
?>
