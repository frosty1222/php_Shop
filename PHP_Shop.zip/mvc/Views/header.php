<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fashion Shop</title>

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <!--important link source from "https://bbbootstrap.com/snippets/mega-menu-navigation-bar-icons-71070657"-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <link rel="stylesheet" href="public/css/bar.css">
    <link rel="stylesheet" href="public/css/product.css">
    <link rel="stylesheet" href="public/css/login.css">
    <link rel="stylesheet" href="public/css/slide2.css">
    <link rel="stylesheet" href="public/css/slide.css" class="text/css">
    <link rel="stylesheet" href="public/css/nav.css" class="text/css">
    <link rel="stylesheet" href="public/css/shop.css" class="text/css">
    <link rel="stylesheet" href="public/css/product_detail.css" class="text/css">
    <!-- <link rel="stylesheet" href="https://path/to/font-awesome/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- rating stars -->
    <link rel="stylesheet" href="public/rate_star/css/star-rating.css" media="all" type="text/css" />
    <link rel="stylesheet" href="public/rate_star/themes/krajee-fa/theme.css" media="all" type="text/css" />
    <link rel="stylesheet" href="public/rate_star/themes/krajee-svg/theme.css" media="all" type="text/css" />
    <link rel="stylesheet" href="public/rate_star/themes/krajee-uni/theme.css" media="all" type="text/css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="public/rate_star/js/star-rating.js" type="text/javascript"></script>
    <script src="public/rate_star/themes/krajee-fa/theme.js" type="text/javascript"></script>
    <script src="public/rate_star/themes/krajee-svg/theme.js" type="text/javascript"></script>
    <script src="public/rate_star/themes/krajee-gly/theme.js" type="text/javascript"></script>
    <script src="public/rate_star/themes/krajee-uni/theme.js" type="text/javascript"></script>
</head>

<body>
    <div class="container_header">
        <div class="header">
            <div class="nav-bar">
                <div class="bar">
                    <ul>
                        <li><a href="index.html"><img id="logo" src="public/image/happy-shop.jpg" alt=""></a></li>
                        <li>About
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>Service
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>Contact
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="#">phone:0353802879</a></li>
                                <li><a href="contact.html">Contact us</a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>User
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="login.html">Login</a></li>
                                <li><a href="register.html">Register</a></li>
                                <li><a href="#">Account</a></li>
                                <li><a href="index.php?controller=Shop&action=logout">Logout</a></li>
                            </ul>
                        </li>
                        <li>Shopping
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="shop.html">Go shopping</a></li>
                                <li><a href="item.html">Go to Cart</a></li>
                                <!-- <li><a href="index.php?controller=Branch&run=admin">Admin View</a></li> -->
                                <li><a href="user.html">User View</a></li>
                            </ul>
                        </li>
                        <li>
                            <?php if (isset($a)) : ?>
                                <?php $c=0; ?>
                                
                                    <center>
                                        <a href="item.html" class="btn btn-default">
                                            <i class="fa fa-cart-plus fa-2x"></i>
                                            <?php foreach ($a as $b) : ?>
                                            <?php $c += $b['quantity']; ?>
                                             <?php endforeach; ?> 
                                            <mark>
                                              <?php echo $c; ?>
                                            </mark>
                                        </a>
                                    </center>
                            <?php else : ?>
                                <center>
                                    <i class="fa fa-cart-plus fa-2x"></i>
                                        <mark>
                                            0
                                        </mark>
                                </center>
                            <?php endif ?>
                        </li>
                        <li class="drop">
                            Views<h2><?php if (isset($_SESSION['number_log'])) {
                                            echo number_format($_SESSION['number_log']);
                                        } ?></h2>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="banner">
            <span>
                <marquee behavior="left" direction=""><img src="https://i.pinimg.com/originals/fe/65/ec/fe65ecad784ce08f61f85aa6f5b33d5b.gif" alt="" width="40px">WELCOME TO MY SHOP</marquee>
            </span>
            <div class="banner-img"><img src="public/image/banner1.jpg" alt="">
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="public/js/slide.js"></script>
    <script src="public/js/slide2.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Latest compiled and minified JS -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <script src="public/js/curson.js"></script>
    <script src="https://kit.fontawesome.com/5ea815c1d0.js"></script>
</body>

</html>