<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fashion Shop</title>

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <!--important link source from "https://bbbootstrap.com/snippets/mega-menu-navigation-bar-icons-71070657"-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <link rel="stylesheet" href="public/css/bar.css">
    <link rel="stylesheet" href="public/css/bar.css">
    <link rel="stylesheet" href="public/css/product.css">
    <link rel="stylesheet" href="public/css/login.css">
    <link rel="stylesheet" href="public/css/slide2.css">
    <link rel="stylesheet" href="public/css/slide.css" class="text/css">
    <link rel="stylesheet" href="public/css/nav.css" class="text/css">
    <!-- <link rel="stylesheet" href="public/css/shop.css"> -->
</head>

<body>
    <div class="container_header">
        <div class="header">
            <div class="nav-bar">
                <div class="bar">
                    <ul>
                        <li><a href="index.php?controller=Shop&action=main">Home</a></li>
                        <li>About
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>Service
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>Contact
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="#">phone:0353802879</a></li>
                                <li><a href="index.php?controller=Branch&run=contact">Contact us</a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>User
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="index.php?controller=Shop&action=login">Login</a></li>
                                <li><a href="index.php?controller=Shop&action=register">Register</a></li>
                                <li><a href="#">Account</a></li>
                            </ul>
                        </li>
                        <li>Shopping
                            <i class="fa fa-angle-down"></i>
                            <ul class="down">
                                <li><a href="index.php?controller=Shop&action=product">Go shopping</a></li>
                                <li><a href="index.php?controller=Shop&action=list_item">Go to Cart</a></li>
                                <li><a href="#"></a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </li>
                        <li>
                            Language Set
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
    <div class="text-center">
        <img src="https://i.pinimg.com/originals/bc/1c/cc/bc1ccce5ee4c1a7a488ea843a0477002.jpg" alt="">
    </div>
    <!-- jQuery -->
    <footer class="text-center text-white" style="background-color: #caced1;">
        <!-- Grid container -->
        <div class="container_footer">
            <!-- Section: Images -->
            <section class="">
                <div class="row">
                    <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
                        <div class="bg-image hover-overlay ripple shadow-1-strong rounded" data-ripple-color="light">
                            <img src="https://mdbootstrap.com/img/new/fluid/city/113.jpg" style="height:91px" />
                            <a href="#!">
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.2);"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
                        <div class="bg-image hover-overlay ripple shadow-1-strong rounded" data-ripple-color="light">
                            <img src="https://mdbootstrap.com/img/new/fluid/city/111.jpg" style="height:91px" />
                            <a href="#!">
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.2);"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
                        <div class="bg-image hover-overlay ripple shadow-1-strong rounded" data-ripple-color="light">
                            <img src="https://mdbootstrap.com/img/new/fluid/city/112.jpg" style="height:91px" />
                            <a href="#!">
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.2);"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
                        <div class="bg-image hover-overlay ripple shadow-1-strong rounded" data-ripple-color="light">
                            <img src="https://mdbootstrap.com/img/new/fluid/city/114.jpg" style="height:91px" />
                            <a href="#!">
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.2);"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
                        <div class="bg-image hover-overlay ripple shadow-1-strong rounded" data-ripple-color="light">
                            <img src="https://mdbootstrap.com/img/new/fluid/city/115.jpg" style="height:91px" />
                            <a href="#!">
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.2);"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
                        <div class="bg-image hover-overlay ripple shadow-1-strong rounded" data-ripple-color="light">
                            <img src="https://mdbootstrap.com/img/new/fluid/city/116.jpg" style="height:91px" />
                            <a href="#!">
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.2);"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Section: Images -->
        </div>
        <!-- Grid container -->

        <!-- Copyright -->
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2020 Copyright: <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Totam quis cumque alias accusantium quam. Vel voluptates eaque dolores ad, animi consequatur impedit labore, harum quod repudiandae quos nemo culpa dolorum.</p>
            <a class="text-white" href="https://mdbootstrap.com/">Fashion Shop</a>
        </div>
        <!-- Copyright -->
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>

</html>