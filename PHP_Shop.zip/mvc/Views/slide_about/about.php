<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
   
     <!-- Latest compiled and minified JS -->
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
</head>

<body>
    <div class="col-md-12">
        <?php include_once('mvc/Views/header.php'); ?>
    </div>
    <div class="khoi-slide">
        <div class="cac-slide">
            <div class="slide active"><img src="https://www.jssor.com/premium/fashion/img/glass-woman.jpg"></div>
            <div class="slide"><img src="https://previews.123rf.com/images/stillab/stillab1709/stillab170900003/86050257-fashionable-concept-men-s-clothes-with-accessories-items-on-white-wooden-board-background.jpg"></div>
            <div class="slide"><img src="https://review.chinabrands.com/chinabrands/seo/image/20181013/20181013032537688950-1.jpg"></div>
            <div class="slide"><img src="https://onlineapply.homecredit.co.in/wp-content/uploads/2021/04/Banner-Size-712X278-Mobile2.png"></div>
        </div>
        <div class="nut-slide">
            <span id="btn-prev"><i class="fad fa-chevron-left fa-2x"></i></span>
            <span id="btn-next"><i class="fad fa-chevron-right fa-2x"></i></span>
            <ul>
                <li class="active_nut"></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
    </div>
    <h1></h1>
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>

</html>
<div class="col-md-12">
    <?php require_once "mvc/Views/footer.php"; ?>
</div>