$(function(){
  // $('.nav-bar .bar ul').hide();
 $('#comment').click(function(){
      $('.comment form') .slideToggle(1000);
  });
});
 